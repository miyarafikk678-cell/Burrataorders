// Before deploy: change this to your deployed backend base URL
// e.g. const API_BASE = 'https://cheesy-backend.onrender.com';
const API_BASE = 'http://localhost:5000';
export { API_BASE };
